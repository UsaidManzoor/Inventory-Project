﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inventory_Managment_System
{
    public partial class Add_User : Form
    {
        public Add_User()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_MouseUp(object sender, MouseEventArgs e)
        {

        }

        private void label3_MouseEnter(object sender, EventArgs e)
        {
            label3.ForeColor = Color.White;
        }

        private void label3_Click(object sender, EventArgs e)
        {
            Add_User  obj1 = new Add_User();
            obj1.MdiParent = this;
            obj1.TopMost = true;
            obj1.Show();
        }

        private void Add_User_Load(object sender, EventArgs e)
        {

        }
    }
}
