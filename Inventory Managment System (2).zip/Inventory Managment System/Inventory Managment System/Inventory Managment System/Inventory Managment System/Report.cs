﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.Sql;

namespace Inventory_Managment_System
{
    public partial class Report : Form
    {
        public Report()
        {
            InitializeComponent();
        }

        private void Report_Load(object sender, EventArgs e)
        {
            

        }

        private void fillByToolStripButton_Click(object sender, EventArgs e)
        {
         

        }

        private void btngen_Click(object sender, EventArgs e)
        {
            try
            {
               //MessageBox.Show(dateTimePicker1.Value+"\n"+dateTimePicker2.Value);
                SqlConnection con = new SqlConnection("Data Source=USAID;Initial Catalog=inventory;Integrated Security=True");
                con.Open();
                DataTable dt = new DataTable();
                DataTable dt1 = new DataTable();

                SqlCommand cmd = new SqlCommand("select S.bill_no as 'Sale Bill',S.pid as 'Sale Product ID',S.cus_id as 'Sale Customer ID',S.qty as 'Sale Quantity',S.total as 'Amount',S.billby as 'Sale Bill By',B.bill_no as 'Purchase Bill No',S.pid as 'Purchase Product ID',B.party_id as 'Purchase Party ID',B.qty as 'Purchase Quantity',B.total as 'Purchase Amount',B.billby as 'Purchase Bill By' from sell S, buy B where (S.date>='" + dateTimePicker1.Value + "' and S.date<='" + dateTimePicker2.Value + "') and (B.date>='" + dateTimePicker1.Value + "' and B.date<='" + dateTimePicker2.Value + "');", con);
                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = cmd;
                da.Fill(dt);
                dataGridView1.DataSource = dt;
                da.Update(dt);



                string query = "select sum(total) from buy where date>='" + dateTimePicker1.Value + "' and date<='" + dateTimePicker2.Value + "';";
                SqlCommand com = new SqlCommand();
                com.CommandText = query;
                com.CommandType = CommandType.Text;
                com.Connection = con;
                double totalpur = (double)com.ExecuteScalar();
                lblpurchase.Text = totalpur.ToString();

                string query1 = "select sum(total) from sell where date>='" + dateTimePicker1.Value + "' and date<='" + dateTimePicker2.Value + "';";
                SqlCommand com1 = new SqlCommand();
                com1.CommandText = query1;
                com1.CommandType = CommandType.Text;
                com1.Connection = con;
                double totalsell = (double)com1.ExecuteScalar();
                lblsale.Text = totalsell.ToString();

                label5.Text = (totalsell - totalpur).ToString();
               
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void dateTimePicker2_ValueChanged(object sender, EventArgs e)
        {

        }
    }
}
