﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.Sql;


namespace Inventory_Managment_System
{
    public partial class Buy : Form
    {
        string user;
        public Buy(string username)
        {
            user = username;
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection("Data Source=USAID;Initial Catalog=inventory;Integrated Security=True");
                con.Open();
                string query = "insert into party (name,ph_no,address,addby) values ('" + txtpname.Text + "','" + txtph_no.Text + "','" + txtp_address.Text + "','" + user + "');";
                SqlCommand com = new SqlCommand();
                com.CommandText = query;
                com.CommandType = CommandType.Text;
                com.Connection = con;
                int res = com.ExecuteNonQuery();
                con.Close();
                if (res == 1)
                {

                    txtpname.Text = "";
                    txtph_no.Text = "";
                    txtp_address.Text = "";
                    MessageBox.Show("Party Added.");
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection("Data Source=USAID;Initial Catalog=inventory;Integrated Security=True");
                con.Open();
                string query = "insert into buy (bill_no,pid,party_id,qty,price,total,date,billby) values ('" + txtrefer.Text + "','" + txtpid.Text + "','" + txt_paid.Text + "','" + txtq.Text + "','" + txtp.Text + "','" + txtt.Text + "',sysdatetime(),'" + user + "');";
                SqlCommand com = new SqlCommand();
                com.CommandText = query;
                com.CommandType = CommandType.Text;
                com.Connection = con;
                int res = com.ExecuteNonQuery();
                con.Close();
                if (res == 1)
                {
                    txtrefer.Text = "";
                    txtpid.Text = "";
                    txt_paid.Text = "";
                    txtq.Text = "";
                    txtp.Text = "";
                    txtt.Text = "";

                    MessageBox.Show("Purchase Confirmed");

                }

            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void txtq_TextChanged(object sender, EventArgs e)
        {
            if(txtp.Text!="" && txtq.Text!=""){
                double price = Convert.ToDouble(txtp.Text);
                int qty = Convert.ToInt32(txtq.Text);
                txtt.Text = (price * qty).ToString();
            }
           
        }

        private void Buy_Load(object sender, EventArgs e)
        {

        }
    }
}
