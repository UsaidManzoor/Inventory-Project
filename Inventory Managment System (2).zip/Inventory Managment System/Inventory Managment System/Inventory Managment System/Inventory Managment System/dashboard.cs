﻿using System;
using System.Configuration;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Inventory_Managment_System
{
    public partial class dashboard : Form
    {
        string username;
        public dashboard(string user)
        {
            
            InitializeComponent();
            toolStripStatusLabel1.Text = user;
            toolStripStatusLabel2.Text =  DateTime.Now.ToShortDateString();
            username = user;
        }
       
        private void exitToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            Application.Exit();
            
        }
        
        private void addToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Add_New obj = new Add_New(username);
            obj.MdiParent = this;
            obj.TopMost = true;
            obj.Show();
        }

        private void addToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Add_New obj = new Add_New (username);
            obj.MdiParent = this;
            obj.TopMost = true;
            obj.Show();
           
        }

        private void allToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Search obj1 = new Search();
            obj1.MdiParent = this;
            obj1.TopMost = true;
            obj1.Show();
        }

        private void addToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            Add_New obj = new Add_New(username);
            obj.MdiParent = this;
            obj.TopMost = true;
            obj.Show();
        }

        private void allToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Search obj1 = new Search();
            obj1.MdiParent = this;
            obj1.TopMost = true;
            obj1.Show();
        }

        private void allToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            Search obj1 = new Search();
            obj1.MdiParent = this;
            obj1.TopMost = true;
            obj1.Show();
        }

        private void reportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Report obj1 = new Report();
            obj1.MdiParent = this;
            obj1.TopMost = true;
            obj1.Show();
        }

        private void logoutToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Add_User obj1 = new Add_User();
            obj1.MdiParent = this;
            obj1.TopMost = true;
            obj1.Show();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void logoutToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=USAID;Initial Catalog=inventory;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand();
            string query = "update  userlog set logout='"+DateTime.Now+"'  where  username='"+toolStripStatusLabel1.Text+"' and logid=(select max(logid) from userlog)";
            cmd.CommandText = query;
            cmd.CommandType = CommandType.Text;
            cmd.Connection = con;
            cmd.ExecuteNonQuery();
            this.Hide();
            Form login = new Form1();
            login.Show();
            con.Close();
            
        }

        private void exitToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=USAID;Initial Catalog=inventory;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand();
            string query = "update  userlog set logout='" + DateTime.Now + "'  where  username='" + toolStripStatusLabel1.Text + "' and logid=(select max(logid) from userlog)";
            cmd.CommandText = query;
            cmd.CommandType = CommandType.Text;
            cmd.Connection = con;
            cmd.ExecuteNonQuery();
            Application.Exit();
            
        }

        private void dashboard_Load(object sender, EventArgs e)
        {
            this.IsMdiContainer = true;
            
        }

        private void dashboard_Resize(object sender, EventArgs e)
        {
            if (this.WindowState == FormWindowState.Minimized || this.WindowState == FormWindowState.Normal)
            {
                for (int i = Application.OpenForms.Count - 1; i >= 0; i--)
                {
                    Application.OpenForms[i].WindowState = FormWindowState.Minimized;
                }
            }
           
        }

        private void dashboard_FormClosing(object sender, FormClosingEventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=USAID;Initial Catalog=inventory;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand();
            string query = "update  userlog set logout='" + DateTime.Now + "'  where  username='" + toolStripStatusLabel1.Text + "' and logid=(select max(logid) from userlog)";
            cmd.CommandText = query;
            cmd.CommandType = CommandType.Text;
            cmd.Connection = con;
            cmd.ExecuteNonQuery();
            Application.Exit();
            con.Close();
        }

        private void customerToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Buy obj1 = new Buy(username);
            obj1.MdiParent = this;
            obj1.TopMost = true;
            obj1.Show();
        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            Sell obj1 = new Sell(username);
            obj1.MdiParent = this;
            obj1.TopMost = true;
            obj1.Show();
        }

        private void changePasswordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Change_Password obj1 = new Change_Password(username);
            obj1.MdiParent = this;
            obj1.TopMost = true;
            obj1.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //richTextBox1.Text= ConfigurationManager.ConnectionStrings["Target"].ConnectionString;
        }
    }
}
