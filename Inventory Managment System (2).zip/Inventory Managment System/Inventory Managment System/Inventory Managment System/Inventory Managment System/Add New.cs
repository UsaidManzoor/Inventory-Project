﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.Sql;

namespace Inventory_Managment_System
{
    public partial class Add_New : Form
    {
        string user;
        public Add_New(string username)
        {
            InitializeComponent();
            user = username;
        }
        
        
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection("Data Source=USAID;Initial Catalog=inventory;Integrated Security=True");
                con.Open();
                string query = "insert into product (pid,name,type,[desc],buy_rate,cell_rate,addby) values ('" + txtpid.Text + "','" + txtname.Text + "','" + txttype.Text + "','" + txtdesc.Text + "'," + Convert.ToDouble(txtbyrate.Text) + "," + Convert.ToDouble(txtsellrate.Text) + ",'" + user + "');";
                SqlCommand com = new SqlCommand();
                com.CommandText = query;
                com.CommandType = CommandType.Text;
                com.Connection = con;
                int res = com.ExecuteNonQuery();
                con.Close();
                if (res == 1)
                {
                    txtpid.Text = "";
                    txtname.Text = "";
                    txttype.Text = "";
                    txtdesc.Text = "";
                    txtbyrate.Text = "";
                    txtsellrate.Text = "";
                    MessageBox.Show("Product Added.");
                }  
            }
            catch(Exception ex)
            {
               MessageBox.Show(ex.Message);
            }
            
        }

        private void Add_New_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection("Data Source=USAID;Initial Catalog=inventory;Integrated Security=True");
                con.Open();
                string query = "insert into customer (name,cell_no,address,addby) values ('" + txtcname.Text + "','" + txtcell_no.Text + "','" + txtc_address.Text + "','" + user + "');";
                SqlCommand com = new SqlCommand();
                com.CommandText = query;
                com.CommandType = CommandType.Text;
                com.Connection = con;
                int res = com.ExecuteNonQuery();
                con.Close();
                if (res == 1)
                {
                    txtcname.Text = "";
                    txtcell_no.Text = "";
                    txtc_address.Text = "";
                    MessageBox.Show("Costumer Added.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection("Data Source=USAID;Initial Catalog=inventory;Integrated Security=True");
                con.Open();
                string query = "insert into party (name,ph_no,address,addby) values ('" + txtpname.Text + "','" + txtph_no.Text + "','" + txtp_address.Text + "','" + user + "');";
                SqlCommand com = new SqlCommand();
                com.CommandText = query;
                com.CommandType = CommandType.Text;
                com.Connection = con;
                int res = com.ExecuteNonQuery();
                con.Close();
                if (res == 1)
                {

                    txtpname.Text = "";
                    txtph_no.Text = "";
                    txtp_address.Text = "";
                    MessageBox.Show("Party Added.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }
    }
}
