﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.Sql;

namespace Inventory_Managment_System
{
    public partial class Sell : Form
    {
        string user;
        public Sell(string username)
        {
            user = username;
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=USAID;Initial Catalog=inventory;Integrated Security=True");
            con.Open();
            string query = "insert into customer (name,cell_no,address,addby) values ('" + txtcname.Text + "','" + txtcell_no.Text + "','" + txtc_address.Text + "','" + user + "');";
            SqlCommand com = new SqlCommand();
            com.CommandText = query;
            com.CommandType = CommandType.Text;
            com.Connection = con;
            int res = com.ExecuteNonQuery();
            con.Close();
            if (res == 1)
            {
                txtcname.Text = "";
                txtcell_no.Text = "";
                txtc_address.Text = "";
                MessageBox.Show("Costumer Added.");
            }
        }

        private void Sell_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection("Data Source=USAID;Initial Catalog=inventory;Integrated Security=True");
                con.Open();
                string query = "insert into sell (bill_no,pid,cus_id,qty,prive,total,date,billby) values ('" + txtref.Text + "','" + txtpid.Text + "','" + txtcus.Text + "','" + txtq.Text + "','" + txtp.Text + "','" + txtt.Text + "',sysdatetime(),'" + user + "');";
                SqlCommand com = new SqlCommand();
                com.CommandText = query;
                com.CommandType = CommandType.Text;
                com.Connection = con;
                int res = com.ExecuteNonQuery();
                con.Close();
                if (res == 1)
                {
                    txtref.Text = "";
                    txtpid.Text = "";
                    txtcus.Text = "";
                    txtq.Text = "";
                    txtp.Text = "";
                    txtt.Text = "";

                    MessageBox.Show("Sold Out");

                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void txtq_TextChanged(object sender, EventArgs e)
        {
            if (txtp.Text != "" && txtq.Text != "")
            {
                double price = Convert.ToDouble(txtp.Text);
                int qty = Convert.ToInt32(txtq.Text);
                txtt.Text = (price * qty).ToString();
            }
        }

        private void txtt_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
