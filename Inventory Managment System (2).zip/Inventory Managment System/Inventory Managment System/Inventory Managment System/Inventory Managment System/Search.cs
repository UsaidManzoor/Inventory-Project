﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace Inventory_Managment_System
{
    public partial class Search : Form
    {
        public Search()
        {
            InitializeComponent();
        }
        DataTable dt = new DataTable();
        DataTable dt1 = new DataTable();
        DataTable dt2 = new DataTable();
        private void Search_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=USAID;Initial Catalog=inventory;Integrated Security=True");
            con.Open();

            SqlCommand cmd1 = new SqlCommand("select * from product;", con);
            SqlDataAdapter da1 = new SqlDataAdapter();
            da1.SelectCommand = cmd1;
            da1.Fill(dt1);
            dataGridView1.DataSource = dt1;
            da1.Update(dt1);


            SqlCommand cmd=new SqlCommand("select * from customer;",con);
            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = cmd;
            da.Fill(dt);
            dataGridView2.DataSource = dt;
            da.Update(dt);

            SqlCommand cmd2 = new SqlCommand("select * from party;", con);
            SqlDataAdapter da2 = new SqlDataAdapter();
            da2.SelectCommand = cmd2;
            da2.Fill(dt2);
            dataGridView3.DataSource = dt2;
            da2.Update(dt2);
            
            
            
            
            con.Close();
            
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            DataView dv = new DataView(dt);
            dv.RowFilter = string.Format("name LIKE '%{0}%'",textBox5.Text);
            dataGridView2.DataSource = dv;
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            DataView dv = new DataView(dt1);
            dv.RowFilter = string.Format("name LIKE '%{0}%'", textBox4.Text);
            dataGridView1.DataSource = dv;
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {
            DataView dv = new DataView(dt2);
            dv.RowFilter = string.Format("name LIKE '%{0}%'", textBox6.Text);
            dataGridView3.DataSource = dv;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            DataView dv = new DataView(dt1);
            dv.RowFilter = string.Format("pid LIKE '%{0}%'", textBox1.Text);
            dataGridView1.DataSource = dv;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
