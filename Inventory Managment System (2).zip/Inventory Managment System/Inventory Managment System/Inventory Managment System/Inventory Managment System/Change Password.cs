﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Inventory_Managment_System
{
    public partial class Change_Password : Form
    {
        string username;
        public Change_Password(string user)
        {
            InitializeComponent();
            username = user;
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=USAID;Initial Catalog=inventory;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand();
            if (txtNew1.Text == txtNew2.Text)
            {
                string query = "update  login set password='" + txtNew1.Text + "'  where  username='" + username + "';";
                cmd.CommandText = query;
                cmd.CommandType = CommandType.Text;
                cmd.Connection = con;
                cmd.ExecuteNonQuery();
                txtNew1.Clear();
                txtNew2.Clear();
                MessageBox.Show("Password has successfully changed. \nNext time you have to login with new Password.");
                con.Close();
            }
            else
            {
                MessageBox.Show(" New Password are not matched.");
            }
        }
    }
}
