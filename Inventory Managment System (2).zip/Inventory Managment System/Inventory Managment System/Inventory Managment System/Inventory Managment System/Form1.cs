﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace Inventory_Managment_System
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnlog_Click(object sender, EventArgs e)
        {
            
        }
       
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label2_MouseEnter(object sender, EventArgs e)
        {
            label2.ForeColor = Color.White;
        }

        private void label1_MouseEnter(object sender, EventArgs e)
        {
            button1.ForeColor = Color.White;
        }

        private void label2_MouseLeave(object sender, EventArgs e)
        {
            label2.ForeColor = Color.Gold;
        }

        private void label1_MouseLeave(object sender, EventArgs e)
        {
            button1.ForeColor = Color.Gold;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.AcceptButton = button1;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //"Data Source=Saadiii;Initial Catalog=inventory;Integrated Security=True"

            SqlConnection con = new SqlConnection("Data Source=USAID;Initial Catalog=inventory;Integrated Security=True");
            con.Open();
            string query = "select count(*) from login where username='" + txtuser.Text.ToString() + "' and password='" + txtpass.Text.ToString() + "'";
            SqlCommand com = new SqlCommand();
            com.CommandText = query;
            com.CommandType = CommandType.Text;
            com.Connection = con;
            int count = (int)com.ExecuteScalar();

            // while ()
            {
                //pass= reader.GetValue(0).ToString();
            }
            if (count == 1)
            {
                MessageBox.Show("Successfully login");
                Form new1 = new dashboard(txtuser.Text);
                new1.Show();
                 
                query = "insert into userlog (username,login) values ('"+txtuser.Text+"','"+DateTime.Now+"')";
                com.CommandText = query;
                com.ExecuteNonQuery();
               
                this.Hide();
                

            }
            else
            {
                MessageBox.Show("incorrect username password");
            }
        }
    }
}
